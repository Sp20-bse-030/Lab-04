/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class runner_H2_Lab4 {
    public static void main(String[]args){
        Account a1 = new Account();
        int z = a1.Setbalance(6000);
        Account a2 = new Account(z);
       
        a2.getbalance();
        a1.Deposit(3000);
        a1.Deposit(3000);
        a2.Withdraw(4000);
        
    }
}
