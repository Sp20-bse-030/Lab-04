/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class Student {
    private String name;
    private double avg;
    private int[] Result_arr = new int [5];
    public Student(String n, int[]array){
        name = n;
        for(int i = 0; i<5; i++){
            Result_arr[i] = array[i];
            
        }
    } 
    public int [] getResult_arr(){
        return Result_arr;
        
    }
    public void setName(String n){
        name = n;
        
    }
    

    public String getName() {
        return name; 
    }
    public void Average(){
        int sum = 0;
         avg = 0;
        for (int i = 0; i< 5; i++){
            sum += Result_arr[i];
            
        }
        avg = sum /5;
        System.out.println("the average is " + avg);
    }
     public double getAvg() {
         return avg;
    }

   
    
}
