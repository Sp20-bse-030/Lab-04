/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class Account {
    private int balance;
    public Account(){
        balance = 5000;
    }
    public Account(int b){
        balance = b;
    }
    public int Setbalance(int b){
        balance = b;
        return balance;
    }
    public int getbalance(){
        return balance;
    }
    public void Deposit(int a){
        int Dep_amount = a;
        //System.out.println("enter your balance you want to deposit");
        int total = balance+Dep_amount;
        System.out.println("your privious balance was " + balance + " you deposit " + Dep_amount + " and now your total balance is " + total);
        balance = total;
    }
    public void Withdraw(int c){
        int wd_amount = c;
        //System.out.println("how much you want to withdraw");
        int total = balance - wd_amount;
        System.out.println("your privious balance was " + balance + " you withdraw " + wd_amount + " and now your total balance is " + total);
        balance = total;
        
    }
   
        
    
    
}
