/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
 public class HotCDogStand{
   private int ID_num;
	private int hotDogsSold;
	
	private static int totalHotDogsSold = 0;
	
	public HotCDogStand()
	{
		ID_num = 0;
		hotDogsSold = 0;
	}
	
	public HotCDogStand(int newID, int newHotDogsSold)
	{
		ID_num = newID;
		hotDogsSold = newHotDogsSold;
		totalHotDogsSold += newHotDogsSold;
	}
	
	public void justSold()
	{
		hotDogsSold++;
		totalHotDogsSold++;
	}
	
	public int getHotDogsSold()
	{
		return hotDogsSold;
	}
	
	public static int getTotalHotDogsSold()
	{
		return totalHotDogsSold;
	}
	
	public int getID_num()
	{
		return ID_num;
	}
 }