/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class runner_Assign1_Lab4 {
    public static void main(String[]args){
        HotCDogStand d1 = new HotCDogStand(763, 2);
	HotCDogStand d2 = new HotCDogStand(756, 56);
	HotCDogStand d3 = new HotCDogStand(948, 10);
        HotCDogStand d4 = new HotCDogStand(967, 189);
        d1.justSold();
	d1.justSold();
	d1.justSold();
		
	d2.justSold();
	d2.justSold();
	d2.justSold();
	d2.justSold();
	d2.justSold();
		
	d3.justSold();
	d3.justSold();
        
        d4.justSold();
	d4.justSold();
		
		
	System.out.println( "ID num " +d1.getID_num()+" sold " + d1.getHotDogsSold()+" stands");
	System.out.println( "ID num " +d2.getID_num()+ " sold " + d2.getHotDogsSold()+ " stands");
	System.out.println( "ID num " +d3.getID_num()+ " sold " + d3.getHotDogsSold()+" stands");
        System.out.println( "ID num " +d4.getID_num()+ " sold " + d4.getHotDogsSold()+" stands");
		
	System.out.println("Total number of hot dogs sold by all hot dog stands: " + HotCDogStand.getTotalHotDogsSold());				
	}	
        
    }

