/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class Marks {
    private int m1,m2,m3;
    public Marks(){
        m1 = 1;
        m2 = 2;
        m3 = 3;
    }
    public Marks(int a,int b,int c){
        m1 = a;
        m2 = b;
        m3 = c;
        
    }
    public void Setm1(int a){
        m1 = a;
    }
    public void Setm2(int b){
        m2 = b;
    }
    public void Setm3(int c){
        m3 = c;
    }
    public int getm1(){
        return m1;
    }
    public int getm2(){
        return m2;
    }
    public int getm3(){
        return m3;
    }
    public void Display(){
        System.out.println("Data members are " + m1 + "," + m2 + " and " + m3);
    }

  
    
    
}
