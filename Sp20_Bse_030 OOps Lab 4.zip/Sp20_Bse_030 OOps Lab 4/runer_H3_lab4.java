/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marks;

/**
 *
 * @author Cyber World
 */
public class runer_H3_lab4 {
     public static void main(String[] args){
       
        int[] S = new int [5];
        
        S[0] = 60;
        S[1] = 17;
        S[2] = 50;
        S[3] = 67;
        S[4] = 30;
        Student s1 =  new Student("Malik",S);
        s1.setName("Haider");
        s1.Average();
        double avg1 = s1.getAvg();
        String st1 = s1.getName();
        
        
        S[0] = 70;
        S[1] = 45;
        S[2] = 78;
        S[3] = 59;
        S[4] = 34;
        
        Student s2 =  new Student("Muhammad",S);
        s2.Average();
        double avg2 = s2.getAvg();
        String st2 = s2.getName();
        
        if (avg1 > avg2)
            System.out.println(st1 +" has average greater than " + st2);
        else if(avg1 < avg2)
            System.out.println(st2 +" has average greater than " + st1);
        else
            System.out.println("Both have same average.");
         
        
    }
    
}
    

